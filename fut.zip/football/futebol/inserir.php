<?php
require_once 'Database.php';
require_once 'Time.php';

// Conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Criar um objeto da classe Time
$time = new Time($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Receber os dados do formulário
    $time->setNome($_POST['nome']);
    $time->setCidade($_POST['cidade']);
    $time->setRival($_POST['rival']);
    $time->setIdPais($_POST['id_pais']);
    $time->setIdLiga($_POST['id_liga']);

    // Tentar criar o time
    if ($time->create()) {
        echo "<p class='alert alert-success'>Time inserido com sucesso!</p>";
        echo "<a href='index.php' class='btn btn-primary'>Voltar</a>";
    } else {
        echo "<p class='alert alert-danger'>Erro ao inserir o time.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserir Novo Time</title>
    <!-- Adicionando o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #007bff;
            text-align: center;
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Inserir Novo Time</h1>

    <!-- Formulário de Inserção -->
    <form method="POST">
        <div class="form-group">
            <label for="nome">Nome do Time</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <div class="form-group">
            <label for="cidade">Cidade</label>
            <input type="text" class="form-control" id="cidade" name="cidade" required>
        </div>
        <div class="form-group">
            <label for="rival">Rival</label>
            <input type="text" class="form-control" id="rival" name="rival" required>
        </div>
        <div class="form-group">
            <label for="id_pais">País</label>
            <select class="form-control" id="id_pais" name="id_pais" required>
                <?php
                $stmt = $db->prepare("SELECT * FROM paises");
                $stmt->execute();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="id_liga">Liga</label>
            <select class="form-control" id="id_liga" name="id_liga" required>
                <?php
                $stmt = $db->prepare("SELECT * FROM ligas");
                $stmt->execute();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='{$row['id']}'>{$row['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-custom btn-lg btn-block">Inserir Time</button>
    </form>

    <div class="text-center mt-3">
        <a href="index.php" class="btn btn-secondary">Voltar para a lista de times</a>
    </div>
</div>

<!-- Scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
