<?php
require_once 'Database.php';
require_once 'Time.php';

// Conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Criar um objeto da classe Time
$time = new Time($db);

// Se o ID foi passado pela URL
if (isset($_GET['id'])) {
    // Buscar o time
    $time->setId($_GET['id']);
    $stmt = $db->prepare("SELECT * FROM times WHERE id = ?");
    $stmt->execute([$time->getId()]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        // Preencher os campos com os dados do time
        $time->setNome($row['nome']);
        $time->setCidade($row['cidade']);
        $time->setRival($row['rival']);
        $time->setIdPais($row['id_pais']);
        $time->setIdLiga($row['id_liga']);
    } else {
        echo "<p>Time não encontrado.</p>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Atualizar os dados
    $time->setNome($_POST['nome']);
    $time->setCidade($_POST['cidade']);
    $time->setRival($_POST['rival']);
    $time->setIdPais($_POST['id_pais']);
    $time->setIdLiga($_POST['id_liga']);

    if ($time->update()) {
        echo "<div class='alert alert-success'>Time atualizado com sucesso!</div>";
        echo "<a href='index.php' class='btn btn-primary'>Voltar</a>";
    } else {
        echo "<div class='alert alert-danger'>Erro ao atualizar o time.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Time</title>
    <!-- Adicionando o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        h1 {
            color: #28a745;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .back-link {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Editar Time</h1>
    <form method="POST">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" class="form-control" value="<?php echo $time->getNome(); ?>" required>
        </div>
        <div class="form-group">
            <label for="cidade">Cidade:</label>
            <input type="text" id="cidade" name="cidade" class="form-control" value="<?php echo $time->getCidade(); ?>" required>
        </div>
        <div class="form-group">
            <label for="rival">Rival:</label>
            <input type="text" id="rival" name="rival" class="form-control" value="<?php echo $time->getRival(); ?>" required>
        </div>
        <div class="form-group">
            <label for="id_pais">País:</label>
            <select name="id_pais" id="id_pais" class="form-control" required>
                <?php
                $stmt = $db->prepare("SELECT * FROM paises");
                $stmt->execute();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $selected = $time->getIdPais() == $row['id'] ? 'selected' : '';
                    echo "<option value='{$row['id']}' {$selected}>{$row['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="id_liga">Liga:</label>
            <select name="id_liga" id="id_liga" class="form-control" required>
                <?php
                $stmt = $db->prepare("SELECT * FROM ligas");
                $stmt->execute();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $selected = $time->getIdLiga() == $row['id'] ? 'selected' : '';
                    echo "<option value='{$row['id']}' {$selected}>{$row['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-custom btn-block">Atualizar Time</button>
    </form>

    <a href="index.php" class="btn btn-secondary back-link">Voltar para a lista de times</a>
</div>

<!-- Scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
