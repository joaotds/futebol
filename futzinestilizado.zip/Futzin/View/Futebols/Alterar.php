<?php

include_once(__DIR__ . "/../../Model/Futebol.php");
include_once(__DIR__ . "/../../Model/Liga.php");
include_once(__DIR__ . "/../../Model/Divisao.php");
include_once(__DIR__ . "/../../Controller/FutebolController.php");

$msgErro = "";
$futebol = null;

$futebolCont = new FutebolController();

if (isset($_POST['timefc'])) {

    // Capturando os dados dos comentários
    $timefc = trim($_POST['timefc']) ? trim($_POST['timefc']) : null;
    $rival = trim($_POST['rival']) ? trim($_POST['rival']) : null;
    $ano = is_numeric($_POST['ano']) ? trim($_POST['ano']) : null;
    $liga = $_POST['liga'];
    $divisao = $_POST['divisao'];
    $idFutebol = $_POST['id'];

    // Criando o objeto futebol para inserir
    $futebol = new Futebol();
    $futebol->settimefc($timefc);
    $futebol->setrival($rival);
    $futebol->setano($ano);

    if ($liga) {
        $ligaObj = new Liga();
        $ligaObj->setId($liga);
        $futebol->setLiga($ligaObj);
    } else
        $futebol->setLiga(null);

    $futebol->setId($idFutebol);

    if ($divisao) {
        $divisaoObj = new Divisao();
        $divisaoObj->setId($divisao);
        $futebol->setDivisao($divisaoObj);
    } else
        $futebol->setDivisao(null);

    $futebol->setId($idFutebol);

    // Chamando a rotina do controller para inserir o futebol
    $erros = $futebolCont->alterar($futebol);

    if (count($erros) <= 0) {
        // Redirecionando para a página lista
        header("location: Listar.php");
    } else {
        $msgErro = implode("<br>", $erros);
        //echo $msgErro;

    }
} else {
    // Rotina para carregar os dados do futebol
    $idFutebol = 0;
    if (isset($_GET['id']))
        $idFutebol = $_GET['id'];

    if ($idFutebol) {
        // Carregar os dados e exibir o formulário
        $futebol = $futebolCont->buscarPorId($idFutebol);
    } else {
        echo "ID do futebol é inválido!<br>";
        echo "<a href='Listar.php'>Voltar</a>";
        exit;
    }
}
include("Form.php");
