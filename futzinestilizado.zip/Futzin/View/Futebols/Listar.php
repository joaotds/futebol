<?php
// Carregando a lista de veículos
include_once(__DIR__ . "/../../Controller/FutebolController.php");

$futebolCont = new FutebolController();
$futebol = $futebolCont->listar();

// Inclusão do HTML do header
include_once(__DIR__ . "/../Include/Header.php");
?>

<!-- Título -->
<h2 class="text-center text-primary font-weight-bold">Listagem de Times</h2>

<!-- Tabela de Veículos -->
<div class="table-responsive mt-4">
    <table class="table table-hover table-bordered table-striped shadow-sm">
        <thead class="thead-dark text-center">
            <tr>
                <th>ID</th>
                <th>TIMEFC</th>
                <th>RIVAL</th>
                <th>ANO</th>
                <th>LIGA</th>
                <th>DIVISÃO</th>
                <th>AÇÕES</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php foreach ($futebol as $f): ?>
                <tr>
                    <td><?= $f->getId(); ?></td>
                    <td><?= $f->getTimefc(); ?></td>
                    <td><?= $f->getRival(); ?></td>
                    <td><?= $f->getAno(); ?></td>
                    <td><?= $f->getLiga(); ?></td>
                    <td><?= $f->getDivisao(); ?></td>
                    <td>
                        <a href="Alterar.php?id=<?= $f->getId(); ?>" class="btn btn-info btn-sm mr-2">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <a href="Excluir.php?id=<?= $f->getId(); ?>" onclick="return confirm('Você deseja excluir esse time?')" class="btn btn-danger btn-sm">
                            <i class="fas fa-trash-alt"></i> Excluir
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Botão para Inserir Novo Futebol -->
<div class="text-center mt-3">
    <a href="Inserir.php" class="btn btn-success btn-lg">Inserir Novo Time</a>
</div>

<!-- Imagem inserida abaixo do botão -->
<div class="text-center mt-4">
    <img src="https://sportsjob.com.br/wp-content/uploads/2020/11/futebol.jpg" alt="Carro de F1" style="width: 180px; height: auto; border-radius: 15px; box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);">
</div>

<?php
include_once(__DIR__ . "/../Include/Footer.php");
?>
