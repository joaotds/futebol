<?php

include_once(__DIR__ . "/../../Model/Futebol.php");
include_once(__DIR__ . "/../../Model/Liga.php");
include_once(__DIR__ . "/../../Model/Divisao.php");
include_once(__DIR__ . "/../../Controller/FutebolController.php");

$msgErro = "";
$futebol = null;

if (isset($_POST['timefc'])) {

    // Capturando os dados dos comentários
    $timefc = trim($_POST['timefc']) ? trim($_POST['timefc']) : null;
    $rival = trim($_POST['rival']) ? trim($_POST['rival']) : null;
    $ano = is_numeric($_POST['ano']) ? trim($_POST['ano']) : null;
    $liga = $_POST['liga'];
    $divisao = $_POST['divisao'];

    // Criando o objeto futebol para inserir
    $futebol = new Futebol();
    $futebol->setTimefc($timefc);
    $futebol->setRival($rival);
    $futebol->setAno($ano);

    if ($liga) {
        $ligaObj = new Liga();
        $ligaObj->setId($liga);
        $futebol->setLiga($ligaObj);
    } else
        $futebol->setLiga(null);

    if ($divisao) {
        $divisaoObj = new Divisao();
        $divisaoObj->setId($divisao);
        $futebol->setDivisao($divisaoObj);
    } else
        $futebol->setDivisao(null);

    $futebol->setId(0);


    // Chamando a rotina do controller para inserir o aluno
    $futebolCont = new FutebolController();
    $erros = $futebolCont->inserir($futebol);

    if (count($erros) <= 0) {
        // Redirecionando para a página lista
        header("location: Listar.php");
    } else {
        $msgErro = implode("<br>", $erros);
    }
}
include("Form.php");