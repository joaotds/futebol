<?php

// Buscar os circuitos para exibir no select
include_once(__DIR__ . "/../../Controller/LigaController.php");
include_once(__DIR__ . "/../../Controller/DivisaoController.php");

$ligaCont = new LigaController();
$liga =  $ligaCont->listar();
$divisaoCont = new DivisaoController();
$divisao =  $divisaoCont->listar();

include_once(__DIR__ . "/../Include/Header.php");
?>

<!-- Título -->
<h2 class="text-center text-danger font-weight-bold">Cadastrar Time</h2>
<br>

<div class="row">
    <div class="col-6">
        <form id="FormFutebol" method="POST">

            <div class="mb-3">
                <label class="form-label" for="txtTimefc">Time:</label>
                <input class="form-control border-secondary" type="text" placeholder="Informe o timefc:"
                    name="timefc" id="txtTimefc" maxlength="70"
                    value="<?= $futebol != null ? $futebol->getTimefc() : "" ?>">
            </div>

            <div class="mb-3">
                <label class="form-label" for="txtRival">Rival:</label>
                <input class="form-control border-secondary" type="text" placeholder="Informe o nome do rival:"
                    name="rival" id="txtRival" maxlength="70"
                    value="<?= $futebol != null ? $futebol->getRival() : "" ?>">
            </div>

            <div class="mb-3">
                <label class="form-label" for="txtAno">Ano de Inauguração:</label>
                <input class="form-control border-secondary" type="number" placeholder="Informe o ano de lançamento:"
                    name="ano" id="txtAno"
                    value="<?= $futebol != null ? $futebol->getAno() : "" ?>">
            </div>

            <div class="mb-3">
                <label class="form-label" for="selLiga">Liga:</label>
                <select class="form-control border-secondary" name="liga" id="selLiga">
                    <option value=""> - Selecione a Liga - </option>

                    <?php foreach ($liga as $l): ?>
                        <option value="<?= $l->getId() ?>"
                            <?php if ($futebol != null && $futebol->getLiga() != null && $futebol->getLiga()->getId() == $l->getId())
                                echo "selected"; ?>>
                            <?= $l ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label" for="selDivisao">Divisão:</label>
                <select class="form-control border-secondary" name="divisao" id="selDivisao">
                    <option value=""> - Selecione a Divisão - </option>

                    <?php foreach ($divisao as $d): ?>
                        <option value="<?= $d->getId() ?>"
                            <?php if ($futebol != null && $futebol->getDivisao() != null && $futebol->getDivisao()->getId() == $d->getId())
                                echo "selected"; ?>>
                            <?= $d ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="hidden" name="id" value="<?= $futebol != null ? $futebol->getId() : "" ?>">

            <div>
                <input class="btn btn-warning btn-sm mt-3" type="submit" value="Cadastrar" />
            </div>

        </form>
    </div>

    <div class="col-6">
        <?php if ($msgErro): ?>
            <div class="alert alert-danger">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <div class="mt-3">
            <a class="btn btn-outline-primary btn-sm" href="Listar.php">Voltar</a>
        </div>

        <?php
        include_once(__DIR__ . "/../Include/Footer.php");
        ?>
