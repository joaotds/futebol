<?php

include_once(__DIR__ . "/Liga.php");
include_once(__DIR__ . "/Divisao.php");

class Futebol
{

    private ?int $id;
    private ?string $timefc;
    private ?string $rival;
    private ?int $ano;
    private ?Liga $liga;
    private ?Divisao $divisao;


    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of timefc
     */
    public function getTimefc(): ?string
    {
        return $this->timefc;
    }

    /**
     * Set the value of timefc
     */
    public function setTimefc(?string $timefc): self
    {
        $this->timefc = $timefc;

        return $this;
    }

    /**
     * Get the value of rival
     */
    public function getRival(): ?string
    {
        return $this->rival;
    }

    /**
     * Set the value of rival
     */
    public function setRival(?string $rival): self
    {
        $this->rival = $rival;

        return $this;
    }

    /**
     * Get the value of ano
     */
    public function getAno(): ?int
    {
        return $this->ano;
    }

    /**
     * Set the value of ano
     */
    public function setAno(?int $ano): self
    {
        $this->ano = $ano;

        return $this;
    }

    /**
     * Get the value of liga
     */
    public function getLiga(): ?Liga
    {
        return $this->liga;
    }

    /**
     * Set the value of liga
     */
    public function setLiga(?Liga $liga): self
    {
        $this->liga = $liga;

        return $this;
    }

    /**
     * Get the value of divisao
     */
    public function getDivisao(): ?Divisao
    {
        return $this->divisao;
    }

    /**
     * Set the value of divisao
     */
    public function setDivisao(?Divisao $divisao): self
    {
        $this->divisao = $divisao;

        return $this;
    }
}