<?php

//Redireciona para a listagem
header("location: ./View/Futebols/Listar.php");
