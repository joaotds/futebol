/* TABELA liga */
CREATE TABLE liga (
    id int AUTO_INCREMENT NOT NULL,
    nome varchar(20) NOT NULL,
    pais varchar(20) NOT NULL,
    CONSTRAINT pk_circuito PRIMARY KEY (id)
);

/* INSERTs liga */
INSERT INTO
    liga (nome, pais)
VALUES ('A-League', 'Austrália');

INSERT INTO
    liga (nome, pais)
VALUES ('Campeonato Marroquino', 'Marrocos');

INSERT INTO liga (nome, pais) VALUES ('Premier League', 'Inglaterra');

INSERT INTO liga (nome, pais) VALUES ('MLS', 'EUA');

INSERT INTO liga (nome, pais) VALUES ('Bundesliga', 'Alemanha');

INSERT INTO liga (nome, pais) VALUES ('Ligue 1', 'França');

INSERT INTO liga (nome, pais) VALUES ('Canadian Premier League', 'Canadá');

INSERT INTO liga (nome, pais) VALUES ('Brasileirao', 'Brasil');

INSERT INTO liga (nome, pais) VALUES ('J-League', 'Japão');

INSERT INTO liga (nome, pais) VALUES ('CSL', 'China');

/* Tabela divisao */
CREATE TABLE divisao (
    id int AUTO_INCREMENT NOT NULL,
    nome varchar(20) NOT NULL,
    numero INT NOT NULL,
    CONSTRAINT pk_divisao PRIMARY KEY (id)
);

/* INSERTs divisao */
INSERT INTO
    divisao (nome, numero)
VALUES ('Serie A', 1);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie B', 2);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie C', 3);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie D', 4);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie E', 5);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie F', 6);

INSERT INTO
    divisao (nome, numero)
VALUES ('Serie G', 7);

INSERT INTO divisao (nome, numero) VALUES ('Estadual', 8);

INSERT INTO
    divisao (nome, numero)
VALUES ('Estadual B', 9);

INSERT INTO divisao (nome, numero) VALUES ('Sem Divisão', 0);

/* TABELA futebol */
CREATE TABLE futebol (
    id int AUTO_INCREMENT NOT NULL,
    rival varchar(20) NOT NULL,
    timefc varchar(20) NOT NULL,
    ano int NOT NULL,
    id_liga int NOT NULL,
    id_divisao int NOT NULL,
    CONSTRAINT pk_futebol PRIMARY KEY (id)
);

ALTER TABLE futebol
ADD CONSTRAINT fk_liga FOREIGN KEY (id_liga) REFERENCES liga (id);

ALTER TABLE futebol
ADD CONSTRAINT fk_divisao FOREIGN KEY (id_divisao) REFERENCES divisao (id);

ALTER TABLE futebol CHANGE COLUMN time timefc VARCHAR(20) NOT NULL;
