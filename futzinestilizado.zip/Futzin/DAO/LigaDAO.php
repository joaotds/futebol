<?php

include_once(__DIR__ . "/../Util/Connection.php");
include_once(__DIR__ . "/../Model/Liga.php");


class LigaDAO
{

    private $conn;

    public function __construct()
    {
        $this->conn = Connection::getConnection();
    }

    public function list()
    {
        $sql = "SELECT * FROM liga";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        return $this->mapLiga($result);
    }

    private function mapLiga(array $result) {
        $ligas = array();

        foreach($result as $reg){
            $liga = new Liga();
            $liga->setId($reg['id']);
            $liga->setNome($reg['nome']);

            array_push($ligas, $liga);

        }

        return $ligas;
    }
}