<?php

include_once(__DIR__ . "/../Util/Connection.php");
require_once(__DIR__ . "/../Model/Futebol.php");

class FutebolDAO
{

    private $conn;

    public function __construct()
    {
        $this->conn = Connection::getConnection();
    }

    public function insert(Futebol $futebol)
    {
        $sql = "INSERT INTO futebol (timefc, rival, ano, id_liga, id_divisao)
                VALUES (?, ?, ?, ?, ?)";

        $stm = $this->conn->prepare($sql);
        $stm->execute(array(
            $futebol->getTimefc(),
            $futebol->getRival(),
            $futebol->getAno(),
            $futebol->getLiga()->getId(),
            $futebol->getDivisao()->getId(),
        ));
    }

    public function delete($id)
    {
        $sql = "DELETE FROM futebol WHERE id = ?";

        $stm = $this->conn->prepare($sql);
        $stm->execute(array($id));
    }

    public function update(Futebol $futebol)
    {
        $conn = Connection::getConnection();

        $sql = "UPDATE futebol SET timefc = ?, rival = ?, ano = ?," .
            " id_liga = ?, id_divisao = ?" .
            " WHERE id = ?";
        $stmt = $conn->prepare($sql);

        $stmt->execute([
            $futebol->getTimefc(),
            $futebol->getRival(),
            $futebol->getAno(),
            $futebol->getLiga()->getId(),
            $futebol->getDivisao()->getId(),
            $futebol->getId(),
        ]);
    }
    public function list()
    {
        $sql = "SELECT f.* , l.nome liga_nome, d.nome divisao_nome
                FROM futebol f
                JOIN liga l ON (l.id = f.id_liga)
                JOIN divisao d ON (d.id = f.id_divisao)";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        $futebol = $this->mapFutebol($result);
        return $futebol;
    }

    public function findById(int $id)
    {
        $conn = Connection::getConnection();

        $sql = "SELECT f.* , l.nome liga_nome, d.nome divisao_nome
                FROM futebol f
                JOIN liga l ON (l.id = f.id_liga)
                JOIN divisao d ON (d.id = f.id_divisao)
                WHERE f.id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();

        //Criar o objeto Aluno
        $futebol = $this->mapFutebol($result);

        if (count($futebol) == 1)
            return $futebol[0];
        elseif (count($futebol) == 0)
            return null;

        die("FutebolDAO.findById - Erro: mais de um futebol" .
            " encontrado para o ID " . $id);
    }

    private function mapFutebol(array $result)
    {
        $futebols = array();

        foreach ($result as $reg) {
            $futebol = new Futebol();
            $futebol->setId($reg['id']);
            $futebol->setTimefc($reg['timefc']);
            $futebol->setRival($reg['rival']);
            $futebol->setAno($reg['ano']);

            $liga = new Liga();
            $liga->setId($reg['id_liga']);
            $liga->setNome($reg['liga_nome']);
            $futebol->setLiga($liga);

            $divisao = new Divisao();
            $divisao->setId($reg['id_divisao']);
            $divisao->setNome($reg['divisao_nome']);
            $futebol->setDivisao($divisao);

            array_push($futebols, $futebol);
        }

        return $futebols;
    }
}
