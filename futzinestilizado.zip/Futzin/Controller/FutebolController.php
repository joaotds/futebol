<?php

include_once(__DIR__ . "/../DAO/FutebolDao.php");
include_once(__DIR__ . "/../Service/FutebolService.php");

class FutebolController
{

    public function listar()
    {
        $futebolDAO = new FutebolDAO();

        $futebol = $futebolDAO->list();
        return $futebol;
    }

    public function buscarPorId($idFutebol)
    {
        $futebolDAO = new FutebolDAO();

        $futebol = $futebolDAO->findById($idFutebol);
        return $futebol;
    }

    public function inserir($futebol)
    {
        $futebolService = new FutebolService();
        $erros = $futebolService->validarDados($futebol);

        if (count($erros) > 0)
            return $erros;

        $futebolDAO = new FutebolDAO();
        $futebolDAO->insert($futebol);
        return array();
    }

    public function alterar($futebol)
    {
        $futebolService = new FutebolService();
        $erros = $futebolService->validarDados($futebol);

        if (count($erros) > 0)
            return $erros;

        $futebolDAO = new FutebolDAO();
        $futebolDAO->update($futebol);
        return array();
    }

    public function deletar($id)
    {
        $futebolDAO = new FutebolDAO();
        $futebolDAO->delete($id);
    }
}
