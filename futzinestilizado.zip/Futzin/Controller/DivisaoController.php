<?php

include_once(__DIR__ . "/../DAO/DivisaoDAO.php");

class DivisaoController
{

    public function listar() {
        $divisaoDAO = new DivisaoDAO();

        return $divisaoDAO ->list();
    }
}