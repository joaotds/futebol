<?php
require_once 'Database.php';
require_once 'Time.php';

// Conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Criar um objeto da classe Time
$time = new Time($db);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Time</title>
    <!-- Adicionando o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        h1 {
            color: #dc3545;
        }
        .btn-custom {
            background-color: #dc3545;
            color: white;
        }
        .btn-custom:hover {
            background-color: #c82333;
        }
        .back-link {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center">Excluir Time</h1>

    <?php
    if (isset($_GET['id'])) {
        // Definir o ID do time a ser excluído
        $time->setId($_GET['id']);

        // Excluir o time
        if ($time->delete()) {
            echo "<div class='alert alert-success'>Time excluído com sucesso!</div>";
            echo "<a href='index.php' class='btn btn-custom'>Voltar para a lista de times</a>";
        } else {
            echo "<div class='alert alert-danger'>Erro ao excluir o time.</div>";
            echo "<a href='index.php' class='btn btn-secondary'>Voltar</a>";
        }
    } else {
        echo "<div class='alert alert-warning'>ID do time não fornecido.</div>";
        echo "<a href='index.php' class='btn btn-secondary'>Voltar</a>";
    }
    ?>

</div>

<!-- Scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
