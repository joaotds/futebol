<?php
class Time {
    private $conn;
    private $table_name = "times";

    public $id;
    public $nome;
    public $cidade;
    public $rival;
    public $id_pais;
    public $id_liga;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Getters e Setters
    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function getCidade() {
        return $this->cidade;
    }

    public function setCidade($cidade) {
        $this->cidade = $cidade;
    }

    public function getRival() {
        return $this->rival;
    }

    public function setRival($rival) {
        $this->rival = $rival;
    }

    public function getIdPais() {
        return $this->id_pais;
    }

    public function setIdPais($id_pais) {
        $this->id_pais = $id_pais;
    }

    public function getIdLiga() {
        return $this->id_liga;
    }

    public function setIdLiga($id_liga) {
        $this->id_liga = $id_liga;
    }

    // Criar um novo time
    public function create() {
        $query = "INSERT INTO {$this->table_name} (nome, cidade, rival, id_pais, id_liga)
                  VALUES (:nome, :cidade, :rival, :id_pais, :id_liga)";
        $stmt = $this->conn->prepare($query);

        // Sanitização
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->cidade = htmlspecialchars(strip_tags($this->cidade));
        $this->rival = htmlspecialchars(strip_tags($this->rival));

        // Bind
        $stmt->bindParam(':nome', $this->nome);
        $stmt->bindParam(':cidade', $this->cidade);
        $stmt->bindParam(':rival', $this->rival);
        $stmt->bindParam(':id_pais', $this->id_pais);
        $stmt->bindParam(':id_liga', $this->id_liga);

        return $stmt->execute();
    }

    // Ler todos os times
    public function read() {
        $query = "SELECT t.id, t.nome, t.cidade, t.rival, p.nome AS pais, l.nome AS liga 
                  FROM {$this->table_name} t
                  JOIN paises p ON t.id_pais = p.id
                  JOIN ligas l ON t.id_liga = l.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Atualizar um time existente
    public function update() {
        $query = "UPDATE {$this->table_name}
                  SET nome = :nome, cidade = :cidade, rival = :rival, id_pais = :id_pais, id_liga = :id_liga
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        // Sanitização
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->cidade = htmlspecialchars(strip_tags($this->cidade));
        $this->rival = htmlspecialchars(strip_tags($this->rival));
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind
        $stmt->bindParam(':nome', $this->nome);
        $stmt->bindParam(':cidade', $this->cidade);
        $stmt->bindParam(':rival', $this->rival);
        $stmt->bindParam(':id_pais', $this->id_pais);
        $stmt->bindParam(':id_liga', $this->id_liga);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }

    // Excluir um time
    public function delete() {
        $query = "DELETE FROM {$this->table_name} WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }
}
?>
