<?php
// Iniciar sessão e incluir arquivos necessários
require_once 'Database.php';
require_once 'Time.php';

// Conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Criar um objeto da classe Time
$time = new Time($db);

// Obter todos os times cadastrados
$stmt = $time->read();
$num = $stmt->rowCount();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>⚽ Catalogo de times ⚽</title>
    <!-- Adicionando o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            color: #007bff;
            text-align: center;
        }
        table {
            margin-top: 20px;
        }
        .btn-custom {
            background-color: #28a745;
            color: white;
        }
        .btn-custom:hover {
            background-color: #218838;
        }
        .btn-danger-custom {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger-custom:hover {
            background-color: #c82333;
        }
        .action-links {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>⚽ Catalogo de Times ⚽</h1>

    <!-- Tabela de Times -->
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Nome</th>
                <th>Cidade</th>
                <th>Rival</th>
                <th>País</th>
                <th>Liga</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($num > 0) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    extract($row);
                    echo "<tr>
                            <td>{$nome}</td>
                            <td>{$cidade}</td>
                            <td>{$rival}</td>
                            <td>{$pais}</td>
                            <td>{$liga}</td>
                            <td class='action-links'>
                                <a href='editar.php?id={$id}' class='btn btn-info btn-sm'>Editar</a>
                                <a href='excluir.php?id={$id}' class='btn btn-danger btn-sm'>Excluir</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>Nenhum time cadastrado</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Link para Inserir Novo Time -->
    <div class="text-center">
        <a href="inserir.php" class="btn btn-custom btn-lg">Inserir novo time</a>
    </div>
</div>

<!-- Scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
