<?php

include_once(__DIR__ . "/../DAO/FutebolDAO.php");
include_once(__DIR__ . "/../Model/Futebol.php");

class FutebolService {

    public function validarDados(Futebol $futebol) {

        $erros = array();

        if(! $futebol->getTimefc())
            array_push($erros, "Informe o time!");

        if(! $futebol->getRival())
            array_push($erros, "Informe o rival do time!");

        if(! $futebol->getAno())
            array_push($erros, "Informe o ano de inauguração!");

        if(! $futebol->getLiga())
            array_push($erros, "Informe a Liga!");

        if(! $futebol->getDivisao())
            array_push($erros, "Informe sua Divisão!");

        return $erros;

    }
}