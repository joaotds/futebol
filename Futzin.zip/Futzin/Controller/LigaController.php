<?php

include_once(__DIR__ . "/../DAO/LigaDAO.php");

class LigaController
{

    public function listar() {
        $ligaDAO = new LigaDAO();

        return $ligaDAO ->list();
    }
}