<?php
// Carregando a lista de veículos
include_once(__DIR__ . "/../../Controller/FutebolController.php");

$futebolCont = new FutebolController();
$futebol = $futebolCont->listar();

// Inclusão do HTML do header
include_once(__DIR__ . "/../Include/Header.php");
?>

<!-- Título -->
<h2 class="text-center text-verde-escuro">Listagem de Times</h2>

<!-- Tabela de Veículos -->
<table class="table table-striped table-bordered mt-4 bg-cinza-claro">
    <thead class="bg-verde-escuro text-white">
        <tr>
            <th>ID</th>
            <th>TIMEFC</th>
            <th>RIVAL</th>
            <th>ANO</th>
            <th>LIGA</th>
            <th>DIVISAO</th>
            <th>EDITAR</th>
            <th>EXCLUIR</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($futebol as $f): ?>
            <tr>
                <td> <?= $f->getId(); ?></td>
                <td> <?= $f->getTimefc(); ?></td>
                <td> <?= $f->getRival(); ?></td>
                <td> <?= $f->getAno(); ?></td>
                <td> <?= $f->getLiga(); ?></td>
                <td> <?= $f->getDivisao(); ?></td>
                <td>
                    <a href="Alterar.php?id=<?= $f->getId(); ?>">
                        <img src="../../IMG/Editar_F1.png" alt="Editar" style="width: 20px;">
                    </a>
                </td>
                <td>
                    <a href="Excluir.php?id=<?= $f->getId(); ?>" onclick="return confirm('Você deseja excluir esse time?')">
                        <img src="../../IMG/Excluir_F1.png" alt="Excluir" style="width: 20px;">
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Botão para Inserir Novo Futebol -->
<div class="text-center mt-3">
    <a href="Inserir.php" class="btn btn-verde-claro btn-sm">Inserir Novo Time</a>
</div>

<!-- Imagem inserida abaixo do botão -->
<div class="text-center mt-4">
    <img src="https://img.freepik.com/vetores-premium/carro-de-corrida-de-formula-verde-com-piloto_1639-31896.jpg?semt=ais_hybrid" alt="Carro de F1" style="width: 150px; height: auto; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);">
</div>

<?php
include_once(__DIR__ . "/../Include/Footer.php");
?>
