<?php

// Buscar os circuitos para exibir no select
include_once(__DIR__ . "/../../Controller/LigaController.php");
include_once(__DIR__ . "/../../Controller/DivisaoController.php");

$ligaCont = new LigaController();
$liga =  $ligaCont->listar();
$divisaoCont = new DivisaoController();
$divisao =  $divisaoCont->listar();

include_once(__DIR__ . "/../Include/Header.php");
?>

<!-- Título -->
<h2 class="text-center text-verde-escuro">Cadastrar Time</h2>
<br>

<div class="row">
    <div class="col-6">
        <form id="FormFutebol" method="POST">

            <div>
                <label class="form-label" for="txtTimefc">Time:</label>
                <input class="form-control" type="text" placeholder="Informe o timefc:"
                    name="timefc" id="txtTimefc" maxlength="70"
                    value="<?= $futebol != null ? $futebol->getTimefc() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="txtRival">Rival:</label>
                <input class="form-control" type="text" placeholder="Informe o nome do rival:"
                    name="rival" id="txtRival" maxlength="70"
                    value="<?= $futebol != null ? $futebol->getRival() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="txtAno">Ano de Inauguração:</label>
                <input class="form-control" type="number" placeholder="Informe o ano de lançamento:"
                    name="ano" id="txtAno"
                    value="<?= $futebol != null ? $futebol->getAno() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="selLiga">Liga:</label>
                <select class="form-control" name="liga" id="selLiga">
                    <option value=""> - Selecione a Liga - </option>

                    <?php foreach ($liga as $l): ?>
                        <option value="<?= $l->getId() ?>"
                            <?php if ($futebol != null && $futebol->getLiga() != null && $futebol->getLiga()->getId() == $l->getId())
                                echo "selected"; ?>>
                            <?= $l ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="form-label" for="selDivisao">Divisao:</label>
                <select class="form-control" name="divisao" id="selDivisao">
                    <option value=""> - Selecione a Divisao - </option>

                    <?php foreach ($divisao as $d): ?>
                        <option value="<?= $d->getId() ?>"
                            <?php if ($futebol != null && $futebol->getDivisao() != null && $futebol->getDivisao()->getId() == $d->getId())
                                echo "selected"; ?>>
                            <?= $d ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>



            <input type="hidden" name="id" value="<?= $futebol != null ? $futebol->getId() : "" ?>">

            <div>
                <input class="btn btn-success btn-sm mt-2" type="submit" value="Cadastrar" />
            </div>

        </form>
    </div>

    <div class="col-6">
        <?php if ($msgErro): ?>
            <div class="alert alert-danger">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <div class="mt-3">
            <a class="btn btn-outline-seccondary btn-sm" href="Listar.php">Voltar</a>
        </div>

        <?php
        include_once(__DIR__ . "/../Include/Footer.php");
        ?>