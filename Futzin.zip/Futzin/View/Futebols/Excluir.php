<?php

include_once(__DIR__ . "/../../Controller/FutebolController.php");

// Capturar o ID do futebol usando a superglobal $_GET
$id = 0;
if (isset($_GET['id']))
    $id = $_GET['id'];

// Chamar o FutebolController para excluir o futebol pelo ID 
$veiculoCont = new FutebolController();
$veiculoCont->deletar($id);

header("location: Listar.php");
