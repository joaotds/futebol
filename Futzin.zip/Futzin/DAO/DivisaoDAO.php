<?php

include_once(__DIR__ . "/../Util/Connection.php");
include_once(__DIR__ . "/../Model/Divisao.php");


class DivisaoDao
{

    private $conn;

    public function __construct()
    {
        $this->conn = Connection::getConnection();
    }

    public function list()
    {
        $sql = "SELECT * FROM divisao";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        return $this->mapDivisao($result);
    }

    private function mapDivisao(array $result) {
        $equipes = array();

        foreach($result as $reg){
            $divisao = new Divisao();
            $divisao->setId($reg['id']);
            $divisao->setNome($reg['nome']);

            array_push($equipes, $divisao);

        }

        return $equipes;
    }
}