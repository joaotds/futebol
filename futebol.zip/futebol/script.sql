/*
paises (id, nome)
ligas (id, nome, divisao)
times (id, nome, cidade, rival, id_liga, id_pais)
*/

CREATE TABLE paises (
    id INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50),
    CONSTRAINT pk_paises PRIMARY KEY (id)
);

INSERT INTO paises (nome) VALUES ('Brasil');
INSERT INTO paises (nome) VALUES ('Inglaterra');
INSERT INTO paises (nome) VALUES ('Italia');
INSERT INTO paises (nome) VALUES ('Espanha');
INSERT INTO paises (nome) VALUES ('Portugal');

CREATE TABLE ligas (
    id INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50),
    divisao INTEGER,
    CONSTRAINT pk_ligas PRIMARY KEY (id)
);

INSERT INTO ligas (nome, divisao) VALUES ('Brasileirão Série A', 1);

INSERT INTO ligas (nome, divisao) VALUES ('Brasileirão Série B', 2);

INSERT INTO ligas (nome, divisao) VALUES ('Brasileirão Série C', 3);

INSERT INTO ligas (nome, divisao) VALUES ('Premier League', 1);

INSERT INTO ligas (nome, divisao) VALUES ('EFL Championship', 2);

INSERT INTO ligas (nome, divisao) VALUES ('Serie A', 1);

INSERT INTO ligas (nome, divisao) VALUES ('Serie B', 2);

INSERT INTO ligas (nome, divisao) VALUES ('Serie C', 3);

INSERT INTO ligas (nome, divisao) VALUES ('LaLiga', 1);

INSERT INTO ligas (nome, divisao) VALUES ('LaLiga SmartBank', 2);

INSERT INTO ligas (nome, divisao) VALUES ('Liga Portugal', 1);

INSERT INTO ligas (nome, divisao) VALUES ('Liga Portugal B', 2);


CREATE TABLE times (
    id INTEGER NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50),
    cidade VARCHAR(50),
    rival VARCHAR(50),
    id_pais INTEGER,
    id_liga INTEGER,
    CONSTRAINT pk_ligas PRIMARY KEY (id)
);
ALTER TABLE times ADD CONSTRAINT fk_times_paises FOREIGN KEY (id_pais) REFERENCES paises (id);
ALTER TABLE times ADD CONSTRAINT fk_times_ligas FOREIGN KEY (id_liga) REFERENCES ligas (id);


