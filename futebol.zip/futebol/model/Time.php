<?php

require_once(__DIR__ . "/Pais.php");
require_once(__DIR__ . "/Liga.php");

class Time {

    private ?int $id;
    private ?string $nome;
    private ?string $cidade;
    private ?string $rival;
    private ?Pais $pais;
    private ?Liga $liga;

    
    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): ?string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(?string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of cidade
     */
    public function getCidade(): ?string
    {
        return $this->cidade;
    }

    /**
     * Set the value of cidade
     */
    public function setCidade(?string $cidade): self
    {
        $this->cidade = $cidade;

        return $this;
    }

    /**
     * Get the value of rival
     */
    public function getRival(): ?string
    {
        return $this->rival;
    }

    /**
     * Set the value of rival
     */
    public function setRival(?string $rival): self
    {
        $this->rival = $rival;

        return $this;
    }

    /**
     * Get the value of pais
     */
    public function getPais(): ?Pais
    {
        return $this->pais;
    }

    /**
     * Set the value of pais
     */
    public function setPais(?Pais $pais): self
    {
        $this->pais = $pais;

        return $this;
    }

    /**
     * Get the value of liga
     */
    public function getLiga(): ?Liga
    {
        return $this->liga;
    }

    /**
     * Set the value of liga
     */
    public function setLiga(?Liga $liga): self
    {
        $this->liga = $liga;

        return $this;
    }
}